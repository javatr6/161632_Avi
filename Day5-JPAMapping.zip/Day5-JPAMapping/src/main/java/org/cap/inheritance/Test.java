package org.cap.inheritance;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpademo");
		EntityManager em = emf.createEntityManager();
		EntityTransaction transaction = em.getTransaction();
		
		transaction.begin();
		
		Module module = new Module();
		module.setProjectId(121);
		module.setProjectName("Trans Vision");
		
		Task task = new Task();
		task.setProjectId(1009);
		task.setProjectName("Discover");
		task.setModuleName("Validation");
		task.setTaskName("Client Validation");
		
		transaction.commit();
		em.close();
	}

}
