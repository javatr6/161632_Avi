package org.cap.manytomany;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class Main {

	public static void main(String[] args) {
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PERSISTENCE");
		EntityManager em = emf.createEntityManager();
		EntityTransaction transaction = em.getTransaction();
		
		transaction.begin();
		
		Events java= new Events();
		java.setEventId("101-JAVA");
		java.setEventName("JAVA");
		
		Events sql= new Events();
		sql.setEventId("456-SQL");
		sql.setEventName("SQL");
		
		Events c= new Events();
		c.setEventId("543-C");
		c.setEventName("C");
		
		Delegates avi= new Delegates(1,"Avinash");
		Delegates ani= new Delegates(2,"Anirudh");
		Delegates akhi= new Delegates(3,"Akhilesh");
		Delegates mani= new Delegates(4,"Manish");
		Delegates cherry= new Delegates(5,"Charan");
		
		avi.getEvents().add(c);
		avi.getEvents().add(java);
		ani.getEvents().add(c);
		ani.getEvents().add(sql);
		akhi.getEvents().add(java);
		akhi.getEvents().add(sql);
		mani.getEvents().add(c);
		mani.getEvents().add(java);
		cherry.getEvents().add(c);
		cherry.getEvents().add(java);
		
		em.persist(avi);
		em.persist(ani);
		em.persist(akhi);
		em.persist(mani);
		em.persist(cherry);
		em.persist(c);
		em.persist(sql);
		em.persist(java);
		
		transaction.commit();
		em.close();
	}

}
